import logging
import random
import threading
import time

from da.csmapi import CSMAPI

log = logging.getLogger("\033[1;35m[DA]: \033[0m")

# example
"""
profile = {
    'd_name': None,
    'dm_name': 'MorSensor',
    'u_name': 'yb',
    'is_sim': False,
    'df_list': ['Acceleration', 'Temperature'],
}
"""


class DANError(Exception):
    pass

class DAN():
    def __init__(self, profile=None, host=None, mac_addr=None):
        self.profile = profile
        if host:
            self.csmapi = CSMAPI('http://{host}:9999'.format(host=host))
        else:
            self.csmapi = CSMAPI(None)

        self.mac_addr = mac_addr

        # for control channel
        #self.state = 'SUSPEND'
        self.state = 'RESUME'                                                  #new

        self.selected_DF = set()
        self.pre_data_timestamp = {}
        self.control_channel_timestamp = None
        self.control_channel_thread = None

    @staticmethod
    def get_mac_addr():
        from uuid import getnode
        mac = getnode()
        mac = ''.join(("%012X" % mac)[i:i + 2] for i in range(0, 12, 2))
        return mac

    def control_channel(self):
        while True:
            time.sleep(60)
            try:
                cc = self.csmapi.pull(self.mac_addr, '__Ctl_O__')
                if not cc:
                    continue

                if self.control_channel_timestamp == cc[0][0]:
                    continue

                self.control_channel_timestamp = cc[0][0]
                cmd = cc[0][1][0]
                if   cmd == 'RESUME':  self.state = 'RESUME'
                elif cmd == 'SUSPEND': self.stste = 'SUSPEND'
                elif cmd == 'SET_DF_STATUS':
                    self.csmapi.push(self.mac_addr,
                                     '__Ctl_I__',
                                     ['SET_DF_STATUS_RSP',
                                      {'cmd_params': cc[0][1][1]['cmd_params']}])
                    df_status = list(cc[0][1][1]['cmd_params'][0])

                    self.profile['df_list'] = self.csmapi.pull(self.mac_addr, 'profile')['df_list'] 
                    self.selected_DF.clear
                    for index, status in enumerate(df_status):
                        if status == '1':
                            self.selected_DF.add(self.profile['df_list'][index])

            except Exception as e:
                log.error(self.profile['d_name'] + ': Control error', e)

    def detect_local_server(self):
        import socket
        udp_ip = ''
        udp_port = 17000

        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((udp_ip, udp_port))

        while True:
            log.info(self.profile['d_name'] + ': Searching for the IoTtalk server...')
            data, addr = s.recvfrom(1024)
            if str(data.decode()) == 'easyconnect':
                self.csmapi.host = 'http://{}:9999'.format(addr[0])
                break

    def register_device(self, profile=None, host=None, mac_addr=None):
        """
        profile = {
            'd_name': None,
            'dm_name': 'MorSensor',
            'u_name': 'yb',
            'is_sim': False,
            'df_list': ['Acceleration', 'Temperature'],
        }
        """
        if profile:
            self.profile = profile
        elif not self.profile:
            raise DANError('profile should be given.')

        self.selected_DF = self.profile['df_list'].copy()                        # new


        if host:
            self.csmapi.host = 'http://{host}:9999'.format(host=host)
        elif not self.csmapi.host:
            _input = input('Do you want to search local server? (y/n):')
            if _input.upper() in ['YES', 'Y']:
                self.detect_local_server()
            else:
                raise DANError('host should be given.')

        if mac_addr:
            self.mac_addr = mac_addr
        elif not self.mac_addr:
            self.mac_addr = DAN.get_mac_addr()

        if not self.profile.get('dm_name'):
            raise DANError('dm_name should be given in profile.')

        if not self.profile.get('d_name'):
            self.profile['d_name'] = str(int(random.uniform(1, 100))) + '.' + self.profile['dm_name']

        if not self.profile.get('u_name'):
            self.profile['u_name'] = 'yb'

        if not self.profile.get('is_sim'):
            self.profile['is_sim'] = False

        if not self.profile.get('df_list'):
            raise DANError('df_list should be given in profile.')

        log.info(self.profile['d_name'] + ': IoTtalk Server = {}'.format(self.csmapi.host))
        if self.csmapi.register(self.mac_addr, self.profile):
            log.info(self.profile['d_name'] + ': Device has successfully registered.')

            '''
            if self.control_channel_thread is None:
                log.info(self.profile['d_name'] + ': Create control threading')
                # for control channel
                self.control_channel_thread = threading.Thread(target=self.control_channel)
                self.control_channel_thread.daemon = True
                self.control_channel_thread.start()
            '''
            return True
        else:
            log.warning(self.profile['d_name'] + ': Registration failed.')
            return False

    def device_registration_with_retry(self, profile=None, host=None, mac_addr=None):

        while True:
            try:
                if self.register_device(profile, host, mac_addr):
                    break
            except Exception as e:
                # TODO: check error
                log.error(self.profile['d_name'] + ': Attach failed: '),
                log.error(e)
            time.sleep(1)

    def pull(self, df_name):
        if self.state == 'RESUME':
            data = self.csmapi.pull(self.mac_addr, df_name)
            if data == [] or  data == None: return None
            if self.pre_data_timestamp.get(df_name) != data[0][0]:
                self.pre_data_timestamp[df_name] = data[0][0]

                if data[0][1]:
                    return data[0][1]

        return None

    def pull_with_timestamp(self, df_name):
        if self.state == 'RESUME':
            data = self.csmapi.pull(self.mac_addr, df_name)
            if data == [] or  data == None: return None
            if self.pre_data_timestamp.get(df_name) != data[0][0]:
                self.pre_data_timestamp[df_name] = data[0][0]

                if data[0][1]:
                    return (data[0][0], data[0][1])

        return None

    def push(self, df_name, *data):
        if self.state == 'RESUME':
            return self.csmapi.push(self.mac_addr, df_name, list(data))

        return None

    def get_alias(self, df_name):
        try:
            alias = self.csmapi.get_alias(self.mac_addr, df_name)
        except Exception as e:
            raise DANError(e)

        return alias

    def set_alias(self, df_name, new_alias_name):
        try:
            alias = self.csmapi.set_alias(self.mac_addr, df_name, new_alias_name)
        except Exception as e:
            raise DANError(e)

        return alias

    def deregister(self):
        return self.csmapi.deregister(self.mac_addr)
